HTTPS Normalization Runbook
1) Replace http:// with https:// for org URLs and logos in templates.
2) Ensure canonical URLs use https. Base host: nrlc.ai.
3) Update sitemap.xml and robots.txt to reference https.
Regex examples:
- Search: \bhttp://nrlc\.ai\b
- Replace: https://nrlc.ai
